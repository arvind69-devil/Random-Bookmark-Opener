chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Handle request to get all bookmarks
    if (request.action === 'getAllBookmarks') {
        chrome.bookmarks.getTree((bookmarkTreeNodes) => {
            const bookmarks = [];

            // Traverse the bookmark tree to find all bookmarks
            const traverse = (node) => {
                if (node.url) {
                    bookmarks.push({
                        title: node.title,
                        url: node.url
                    });
                }
                if (node.children) {
                    node.children.forEach(traverse);
                }
            };

            bookmarkTreeNodes.forEach(traverse);

            if (bookmarks.length === 0) {
                console.log("No bookmarks found.");
                sendResponse({ success: false, message: "No bookmarks found." });
                return;
            }

            sendResponse({
                success: true,
                bookmarks: bookmarks
            });
        });

        return true; // Required to use sendResponse asynchronously
    }

    // For backward compatibility, still handle the original getRandomBookmarks
    if (request.action === 'getRandomBookmarks') {
        const count = request.count || 5;

        chrome.bookmarks.getTree((bookmarkTreeNodes) => {
            const bookmarks = [];

            const traverse = (node) => {
                if (node.url) {
                    bookmarks.push(node);
                }
                if (node.children) {
                    node.children.forEach(traverse);
                }
            };

            bookmarkTreeNodes.forEach(traverse);

            if (bookmarks.length === 0) {
                console.log("No bookmarks found.");
                sendResponse({ success: false, message: "No bookmarks found." });
                return;
            }

            const randomBookmarks = [];
            const maxCount = Math.min(count, bookmarks.length);
            const bookmarksCopy = [...bookmarks];

            for (let i = 0; i < maxCount; i++) {
                const randomIndex = Math.floor(Math.random() * bookmarksCopy.length);
                randomBookmarks.push(bookmarksCopy[randomIndex]);
                bookmarksCopy.splice(randomIndex, 1);
            }

            sendResponse({
                success: true,
                bookmarks: randomBookmarks.map(bookmark => ({
                    title: bookmark.title,
                    url: bookmark.url
                }))
            });
        });

        return true;
    }
});