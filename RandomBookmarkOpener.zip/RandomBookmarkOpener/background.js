chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'openRandomBookmark') {
        chrome.bookmarks.getTree((bookmarkTreeNodes) => {
            const bookmarks = [];
            const traverse = (node) => {
                if (node.url) {
                    bookmarks.push(node);
                }
                if (node.children) {
                    node.children.forEach(traverse);
                }
            };
            bookmarkTreeNodes.forEach(traverse);
            if (bookmarks.length === 0) {
                console.log("No bookmarks found.");
                sendResponse({ success: false, message: "No bookmarks found." });
                return;
            }
            const randomIndex = Math.floor(Math.random() * bookmarks.length);
            const randomBookmark = bookmarks[randomIndex];
            chrome.tabs.create({ url: randomBookmark.url }, () => {
                sendResponse({ success: true, message: `Opened: ${randomBookmark.title} - ${randomBookmark.url}` });
            });
        });
        return true; // Required to use sendResponse asynchronously
    }
});