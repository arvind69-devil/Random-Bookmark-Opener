let allBookmarks = [];
let DISPLAY_COUNT = 5;

// Function to get a single random bookmark that isn't already in the displayed list
function getRandomBookmark(displayedBookmarks) {
    if (allBookmarks.length === 0) return null;

    const availableBookmarks = allBookmarks.filter(bookmark =>
        !displayedBookmarks.some(displayed => displayed.url === bookmark.url)
    );

    if (availableBookmarks.length === 0) return null;

    const randomIndex = Math.floor(Math.random() * availableBookmarks.length);
    return availableBookmarks[randomIndex];
}

// Function to search bookmarks
function searchBookmarks(searchTerm) {
    searchTerm = searchTerm.toLowerCase();
    return allBookmarks.filter(bookmark => {
        const titleMatch = bookmark.title && bookmark.title.toLowerCase().includes(searchTerm);
        const urlMatch = bookmark.url && bookmark.url.toLowerCase().includes(searchTerm);
        return titleMatch || urlMatch;
    });
}

// Function to create a bookmark item
function createBookmarkItem(bookmark) {
    const listItem = document.createElement('li');
    listItem.className = 'bookmark-item';
    listItem.textContent = bookmark.title || bookmark.url;
    listItem.title = bookmark.url;

    const closeBtn = document.createElement('span');
    closeBtn.className = 'close-btn';
    closeBtn.textContent = 'X';

    closeBtn.addEventListener('click', (event) => {
        event.stopPropagation();
        replaceBookmark(listItem);
    });

    listItem.addEventListener('click', () => {
        chrome.tabs.create({ url: bookmark.url, active: false });
        const statusDiv = document.getElementById('status');
        statusDiv.textContent = `Opened in background: ${bookmark.title}`;
        replaceBookmark(listItem);
    });

    listItem.appendChild(closeBtn);
    listItem.dataset.url = bookmark.url;
    return listItem;
}

// Function to replace a bookmark with a new random one
function replaceBookmark(listItem) {
    const bookmarkList = document.getElementById('bookmarkList');
    const statusDiv = document.getElementById('status');

    const displayedItems = bookmarkList.querySelectorAll('li');
    const displayedBookmarks = Array.from(displayedItems).map(item => ({
        url: item.dataset.url
    }));

    const newBookmark = getRandomBookmark(displayedBookmarks);

    if (newBookmark) {
        const newItem = createBookmarkItem(newBookmark);
        bookmarkList.replaceChild(newItem, listItem);
        statusDiv.textContent = `Replaced with: ${newBookmark.title}`;
    } else {
        bookmarkList.removeChild(listItem);
        statusDiv.textContent = 'No more unique bookmarks available';
    }
}

// Function to display bookmarks in the list
function displayBookmarks(bookmarksToDisplay) {
    const bookmarkList = document.getElementById('bookmarkList');
    const statusDiv = document.getElementById('status');

    bookmarkList.innerHTML = '';

    if (bookmarksToDisplay.length === 0) {
        statusDiv.textContent = 'No bookmarks found.';
        return;
    }

    const displayCount = Math.min(DISPLAY_COUNT, bookmarksToDisplay.length);
    for (let i = 0; i < displayCount; i++) {
        const listItem = createBookmarkItem(bookmarksToDisplay[i]);
        bookmarkList.appendChild(listItem);
    }

    statusDiv.textContent = `Found ${displayCount} bookmark${displayCount !== 1 ? 's' : ''}.`;
}

// Event listeners for buttons
document.getElementById('getRandomBookmarks').addEventListener('click', fetchAndDisplayRandomBookmarks);
document.getElementById('refreshBookmarks').addEventListener('click', fetchAndDisplayRandomBookmarks);
document.getElementById('searchButton').addEventListener('click', performSearch);
document.getElementById('searchInput').addEventListener('keyup', (event) => {
    if (event.key === "Enter") performSearch();
});

// Update DISPLAY_COUNT dynamically
const displayCountInput = document.getElementById('displayCount');
displayCountInput.addEventListener('change', () => {
    const newCount = parseInt(displayCountInput.value, 10);
    if (newCount >= 2 && newCount <= 10) {
        DISPLAY_COUNT = newCount;
        fetchAndDisplayRandomBookmarks(); // Refresh bookmarks with new count
    } else {
        alert('Please enter a number between 2 and 10.');
        displayCountInput.value = DISPLAY_COUNT; // Reset to valid value
    }
});

// Fetch and display random bookmarks
function fetchAndDisplayRandomBookmarks() {
    const statusDiv = document.getElementById('status');
    const loader = document.getElementById('loader');

    statusDiv.textContent = 'Getting random bookmarks...';
    loader.style.display = 'block';

    chrome.runtime.sendMessage({ action: 'getAllBookmarks' }, (response) => {
        loader.style.display = 'none';

        if (chrome.runtime.lastError) {
            statusDiv.textContent = 'Error: Could not retrieve bookmarks.';
            console.error(chrome.runtime.lastError);
            return;
        }

        if (response && response.success) {
            allBookmarks = response.bookmarks;

            if (allBookmarks.length === 0) {
                statusDiv.textContent = 'No bookmarks found.';
                return;
            }

            const displayedBookmarks = [];
            for (let i = 0; i < Math.min(DISPLAY_COUNT, allBookmarks.length); i++) {
                const randomBookmark = getRandomBookmark(displayedBookmarks);
                if (randomBookmark) displayedBookmarks.push(randomBookmark);
            }

            displayBookmarks(displayedBookmarks);
        } else {
            statusDiv.textContent = 'No bookmarks found.';
        }
    });
}

// Perform search functionality
function performSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchTerm = searchInput.value.trim();
    const statusDiv = document.getElementById('status');
    const loader = document.getElementById('loader');

    if (searchTerm === '') {
        statusDiv.textContent = 'Please enter a search term.';
        return;
    }

    statusDiv.textContent = `Searching for "${searchTerm}"...`;
    loader.style.display = 'block';

    if (allBookmarks.length === 0) {
        chrome.runtime.sendMessage({ action: 'getAllBookmarks' }, handleSearchResults);
    } else {
        handleSearchResults({ success: true, bookmarks: allBookmarks });
    }

    function handleSearchResults(response) {
        loader.style.display = 'none';

        if (chrome.runtime.lastError) {
            statusDiv.textContent = 'Error: Could not perform search.';
            console.error(chrome.runtime.lastError);
            return;
        }

        if (response && response.success) {
            if (!allBookmarks.length) allBookmarks = response.bookmarks;

            const matchingBookmarks = searchBookmarks(searchTerm);

            if (matchingBookmarks.length === 0) {
                statusDiv.textContent = `No bookmarks found matching "${searchTerm}".`;

                const randomResults = [];
                for (let i = 0; i < Math.min(DISPLAY_COUNT, allBookmarks.length); i++) {
                    const randomBookmark = getRandomBookmark(randomResults);
                    if (randomBookmark) randomResults.push(randomBookmark);
                }

                if (randomResults.length > 0) {
                    displayBookmarks(randomResults);
                    statusDiv.textContent += ' Showing random bookmarks instead.';
                }
                return;
            }

            let resultsToDisplay = [...matchingBookmarks];

            if (matchingBookmarks.length < DISPLAY_COUNT) {
                const additionalNeeded = DISPLAY_COUNT - matchingBookmarks.length;
                for (let i = 0; i < additionalNeeded; i++) {
                    const randomBookmark = getRandomBookmark(resultsToDisplay);
                    if (randomBookmark) resultsToDisplay.push(randomBookmark);
                }
            }

            if (resultsToDisplay.length > DISPLAY_COUNT) {
                resultsToDisplay = resultsToDisplay.slice(0, DISPLAY_COUNT);
            }

            displayBookmarks(resultsToDisplay);

            const matchCount = matchingBookmarks.length;
            if (matchCount < DISPLAY_COUNT) {
                statusDiv.textContent = `Found ${matchCount} bookmark${matchCount !== 1 ? 's' : ''} matching "${searchTerm}". Added random bookmarks to complete the list.`;
            } else {
                statusDiv.textContent = `Found ${matchCount} bookmark${matchCount !== 1 ? 's' : ''} matching "${searchTerm}". Showing ${DISPLAY_COUNT}.`;
            }
        } else {
            statusDiv.textContent = 'Error performing search.';
        }
    }
}

// Add event listeners for GitHub and PayPal buttons
document.getElementById('githubButton').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://github.com/arvind69-devil/Random-Bookmark-Opener' });
});

document.getElementById('paypalButton').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://paypal.me/arvindranga69' });
});