document.getElementById('openRandomBookmark').addEventListener('click', () => {
    const statusDiv = document.getElementById('status');
    const loader = document.getElementById('loader');
    statusDiv.textContent = 'Opening a random bookmark...';
    loader.style.display = 'block'; // Show loader

    chrome.runtime.sendMessage({ action: 'openRandomBookmark' }, (response) => {
        loader.style.display = 'none'; // Hide loader
        if (chrome.runtime.lastError) {
            statusDiv.textContent = 'Error: Could not open a bookmark.';
            console.error(chrome.runtime.lastError);
        } else if (response && response.success) {
            statusDiv.textContent = `Opened: ${response.message}`;
        } else {
            statusDiv.textContent = 'No bookmarks found.';
        }
    });
});

document.getElementById('refreshBookmarks').addEventListener('click', () => {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = 'Refreshing bookmarks...';
    setTimeout(() => {
        statusDiv.textContent = 'Bookmarks refreshed! Ready to open a random bookmark.';
    }, 1000); // Simulate a refresh delay
});